/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho2;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedQueue<T> implements Iterable{

    private LinkedList<T> queue;
   
    public LinkedQueue(){
        queue = new LinkedList<>();
    }
    
    public void enqueue(T element) {
        queue.add(element);
    }
    
    public boolean isEmpty(){
        return queue.isEmpty();
    }
    
    public T dequeue(){
        if(!queue.isEmpty()){
            return queue.remove(0);
        }else{
            return null;
        }
    } 
    
    public T head(){
        if(!queue.isEmpty()){
            return queue.get(0);
        }else{
            return null;
        }
    } 
    
    public int size(){
        return queue.size();
    }
    
    public void clear(){
        queue.clear();
    }
    
    @Override
    public String toString(){
        return queue.toString();
    }

    @Override
    public Iterator iterator() {
        return queue.iterator();
    }
    
}
