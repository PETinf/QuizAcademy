/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho2;


public class Caixa {
    private boolean preferencial;
    private boolean estaAtendendo;
    private Cliente clienteAtual;
    private int tempoAtendimento;
    private int nroClientesAtendidos;

    public Caixa(boolean preferencial) {
        estaAtendendo = false;
        this.preferencial = preferencial;
        this.clienteAtual = null;
        this.tempoAtendimento = 0;
        nroClientesAtendidos = 0;
    }

    public boolean isPreferencial() {
        return preferencial;
    }

    public void setPreferencial(boolean preferencial) {
        this.preferencial = preferencial;
    }

    public Cliente getClienteAtual() {
        return clienteAtual;
    }
    //Troca de cliente e devolve o tempo que esperado
    public int setClienteAtual(Cliente clienteAtual) {
        setEstaAtendendo(true);
        this.clienteAtual = clienteAtual;
        tempoAtendimento = 0;
        return clienteAtual.getTempoDeEspera();
        //System.out.println(clienteAtual.getNome()+" começou a ser atendido!");
    }

    public int getTempoAtendimento() {
        return tempoAtendimento;
    }

    public void addTempoAtendimento() {
        tempoAtendimento++;
    }
    
    public void verificaAtendimentoCliente(){
        if(tempoAtendimento >= clienteAtual.getTempoAtendimento()){
            //System.out.println(clienteAtual.getNome()+" atendido!");
            setEstaAtendendo(false);
            nroClientesAtendidos++;
        }
    }

    public int getNroClientesAtendidos() {
        return nroClientesAtendidos;
    }

    public boolean estaAtendendo() {
        return estaAtendendo;
    }

    public void setEstaAtendendo(boolean estaAtendendo) {
        this.estaAtendendo = estaAtendendo;
    }
    
    
}
