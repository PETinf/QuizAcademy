/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho2;

import java.util.Random;

public class Cliente {
    private String nome;
    private int idade;
    private int tempoAtendimento;
    private int tempoDeEspera;
    private boolean prioritario;
    private Random random;

    public Cliente(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
        if(idade >= 65){
            prioritario = true;
        }else{
            prioritario = false;
        }
        random = new Random();
        tempoAtendimento = random.nextInt(6)+5;
        tempoDeEspera = 0;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }
    
    public int getTempoAtendimento(){
        return tempoAtendimento;
    }

    public boolean isPrioritario() {
        return prioritario;
    }

    public void setPrioritario(boolean prioritario) {
        this.prioritario = prioritario;
    }

    public int getTempoDeEspera() {
        return tempoDeEspera;
    }

    public void addTempoDeEspera() {
        tempoDeEspera++;
    }

    @Override
    public String toString() {
        return "Cliente{" + "nome=" + nome + ", idade=" + idade + ", tempoAtendimento=" + tempoAtendimento + ", prioritario=" + prioritario + '}';
    }
    
    
}
