/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho2;

import java.util.Random;

/**
 *
 * @author User
 */
public class Trabalho2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int nroCaixas = 4;
       int tempoDeSimulado = 60;
       int probabilidade = 7;
       Simulacao s = new Simulacao();
       
       s.iniciarSimulacao(nroCaixas, tempoDeSimulado, probabilidade);
       s.gerarRelatorio();
       
       s.zerarSimulado();
       nroCaixas = 6;
       s.iniciarSimulacao(nroCaixas, tempoDeSimulado, probabilidade);
       s.gerarRelatorio();
       
       s.zerarSimulado();
       nroCaixas = 8;
       s.iniciarSimulacao(nroCaixas, tempoDeSimulado, probabilidade);
       s.gerarRelatorio();
       
       
    }
    
}
