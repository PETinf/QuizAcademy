/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho2;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

/**
 *
 * @author User
 */
public class Simulacao {
    
    private List<Caixa> caixas;
    private LinkedQueue filaNormal;
    private LinkedQueue filaPreferencial;
    private GeradorDeCliente gerador;
    private double mediaTempoDeEspera;
    private int tempoDeSimulacao;
    private int probabilidade;
    private int tamanhoMaximoFilaNormal;
    private int tamanhoMaximoFilaPreferencial;

    public Simulacao() {
        zerarSimulado();
    }
    
    public void iniciarSimulacao(int nroCaixas, int tempoDeSimulacao, int probabilidade){
        this.tempoDeSimulacao = tempoDeSimulacao;
        this.probabilidade = probabilidade;
        iniciarCaixas(nroCaixas);
        gerador = new GeradorDeCliente(probabilidade);
        
        for(int i=0; i < tempoDeSimulacao; i++){
            //System.out.println("\nTempo: "+(i+1)+":");
            Cliente c = gerador.gerarCliente();
            //System.out.println(c);
            if(c != null){
                if(c.isPrioritario()){
                    filaPreferencial.enqueue(c);
                }else{
                    filaNormal.enqueue(c);
                }
            }
            
            for(Caixa caixa: caixas){
                //System.out.print("\nCaixa "+(j+1)+": ");
                if(caixa.estaAtendendo()){
                    caixa.addTempoAtendimento();
                    caixa.verificaAtendimentoCliente();
                }else{
                    atenderCliente(caixa);
                }
            }
            
            atualizarTempoDeEspera();
            verificarTamanhoFilas();
            //System.out.println("Fila Normal: "+filaNormal.size());
            //System.out.println("Fila Preferencial: "+filaPreferencial.size());
        }
    }
    
    public void atenderCliente(Caixa caixa){
        
        if(caixa.isPreferencial()){
            if(!filaPreferencial.isEmpty()){
                mediaTempoDeEspera += caixa.setClienteAtual((Cliente)filaPreferencial.dequeue());
            }else if(!filaNormal.isEmpty()){
                mediaTempoDeEspera += caixa.setClienteAtual((Cliente)filaNormal.dequeue()); 
            }
        }else{
            if(!filaNormal.isEmpty()){
                mediaTempoDeEspera += caixa.setClienteAtual((Cliente)filaNormal.dequeue());
            }else if(!filaPreferencial.isEmpty()){
                mediaTempoDeEspera += caixa.setClienteAtual((Cliente)filaPreferencial.dequeue());
            }
        }
        
    }
    
    public void iniciarCaixas(int nroCaixas){
        for(int i=0; i<nroCaixas; i++){
            if(i < nroCaixas/2){
                caixas.add(new Caixa(true));
            }else{
                caixas.add(new Caixa(false));
            }
        }
    }
    
    public int getNroClientesGerados(){
        return gerador.getNroClientesGerados();
    }
    
    public int getNroClientesAtendidos(){
        int nro = 0;
        for(Caixa caixa: caixas){
            nro += caixa.getNroClientesAtendidos();
        }
        return nro;
    }
    
    public void atualizarTempoDeEspera(){
        ListIterator<Cliente> it = (ListIterator<Cliente>) filaPreferencial.iterator();
        while(it.hasNext()){
            Cliente c = it.next();
            c.addTempoDeEspera();
        }
        it = (ListIterator<Cliente>) filaNormal.iterator();
        while(it.hasNext()){
            Cliente c = it.next();
            c.addTempoDeEspera();
        }
    }

    public double getMediaTempoDeEspera() {
        return mediaTempoDeEspera/getNroClientesAtendidos();
    }

    public int getTempoDeSimulacao() {
        return tempoDeSimulacao;
    }

    public int getTamanhoMaximoFilaNormal() {
        return tamanhoMaximoFilaNormal;
    }

    public int getTamanhoMaximoFilaPreferencial() {
        return tamanhoMaximoFilaPreferencial;
    }
    
    public void verificarTamanhoFilas(){
        if(filaNormal.size()>tamanhoMaximoFilaNormal){
            tamanhoMaximoFilaNormal = filaNormal.size();
        }
        if(filaPreferencial.size()>tamanhoMaximoFilaPreferencial){
            tamanhoMaximoFilaPreferencial = filaPreferencial.size();
        }
    }
    
    public void zerarSimulado(){
        this.caixas = new ArrayList<>();
        this.filaNormal = new LinkedQueue();
        this.filaPreferencial = new LinkedQueue();
        mediaTempoDeEspera = 0;
        tamanhoMaximoFilaNormal = 0;
        tamanhoMaximoFilaPreferencial = 0;
    }
    
    public void gerarRelatorio(){
        String relatorio = "---------------------- RELATÓRIO ----------------------\n\n";
        relatorio += "Tempo de simulação: "+tempoDeSimulacao;
        relatorio += "\nNúmero de Caixas: "+caixas.size();
        relatorio += "\nProbabilidade de entrada de clientes: "+probabilidade;
        relatorio += "\nNúmero de Clientes gerados: "+getNroClientesGerados();
        relatorio += "\nNúmero de Clientes atendidos: "+getNroClientesAtendidos();
        relatorio += "\nMédia de tempo de espera: "+getMediaTempoDeEspera();
        relatorio += "\nNúmero de clientes prioritários gerados: "+gerador.getPrioritarios();
        relatorio += "\nNúmero de clientes normais gerados: "+gerador.getNormais();
        relatorio += "\nTamanho máximo da fila normal: "+tamanhoMaximoFilaNormal;
        relatorio += "\nTamanho máximo da fila preferencial: "+tamanhoMaximoFilaPreferencial;
        System.out.println(relatorio);
    }
}

