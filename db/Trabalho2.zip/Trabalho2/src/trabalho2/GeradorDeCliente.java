/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho2;

import java.util.Random;


public class GeradorDeCliente {
    
    private static final String DEFAULTNAME = "CLIENTE ";
    private int nroClientesGerados;
    private int probabilidade;
    private int prioritarios;
    private int normais;
    Random random = new Random();
    
    public GeradorDeCliente(int probabilidade){
        this.probabilidade = probabilidade;
        nroClientesGerados = 0;
        prioritarios = 0;
        normais = 0;
    }

    public int getNroClientesGerados() {
        return nroClientesGerados;
    }

    public void setNroClientesGerados(int nroClientesGerados) {
        this.nroClientesGerados = nroClientesGerados;
    }

    public int getProbabilidade() {
        return probabilidade;
    }

    public void setProbabilidade(int probabilidade) {
        this.probabilidade = probabilidade;
    }
    
    public Cliente gerarCliente(){
        int nroAleatorio = random.nextInt(10)+1;
        if(probabilidade >= nroAleatorio){
            String nome = DEFAULTNAME + nroClientesGerados;
            int idade;
            nroAleatorio = random.nextInt(10)+1;
            if(nroAleatorio <= 4){
                idade = random.nextInt(31)+65;
                prioritarios++;
            }else{
                idade = random.nextInt(47)+18;
                normais++;
            }
            nroClientesGerados++;
            return new Cliente(nome, idade);
        }else{
            return null;
        }
    }

    public int getPrioritarios() {
        return prioritarios;
    }

    public int getNormais() {
        return normais;
    }
    
    
}
